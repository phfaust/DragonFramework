package framework;
import java.lang.reflect.Method;

public interface CommandHandler 
{
	public void process(Object o, Object arg, Method m, DragonFramework df) throws Exception;
}
